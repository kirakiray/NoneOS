import { EverCache } from "../../ever-cache/main.js";

const storage = new EverCache("remote-file-cache");

export const getCache = (key) => {
  debugger;
};

export const saveCache = (key, chunk) => {
  debugger;
};
