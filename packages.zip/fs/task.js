import { flatHandle } from "./util.js";

// 进行中的任务
const tasks = [];

// 通过进度的模式，将文件从源拷贝到目标
export const copyTo = async ({ source, target, confirm, success }) => {
  // 先扁平化所有文件
  const files = await flatHandle(source);

  if (confirm) {
    const result = await confirm(files);

    if (!result) {
      return;
    }
  }

  // 先计算目标的所有的文件，并计算所有块数据，切块按照 1mb 的大小获取hash
  await Promise.all(
    files.map(async (e) => {
      const result = await e.handle._getHashMap({
        size: 1024 * 1024,
      });

      e.hashs = result;
    })
  );

  // 建立一个复制专用的文件夹
  const cacheDir = await target.get(`${source.name}.fs_task_cache`, {
    create: "dir",
  });

  console.log(files.map((e) => e.hashs));

  // 将块复制到缓存文件夹
  for (let handle of files) {
    const hashs = handle.hashs.slice(1);

    for (let hash of hashs) {
      // 确认没有缓存
      const cacheChunk = await cacheDir.get(hash);

      if (cacheChunk) {
        // 已经存在的不用再拷贝
        debugger;
        continue;
      }

      // 获取块数据
      const chunk = await handle._getChunk();
      debugger;
    }

    debugger;
  }
  debugger;

  // 复制完成后，将块重新进行组装
};
