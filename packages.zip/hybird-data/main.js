export class HybirdData extends $.Stanz {
  constructor() {
    
  }
}
