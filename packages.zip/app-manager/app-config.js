export const home = "./apps.html";
