// 初始化核心的方法
import "./cert/init.js";
import "./user-connect/main.js";
import "./server-connect/main.js";
