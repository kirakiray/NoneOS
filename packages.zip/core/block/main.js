import { EverCache } from "../../libs/ever-cache/main.js";
import { userMiddleware } from "../main.js";
import {
  CHUNK_REMOTE_SIZE,
  calculateHash,
  splitIntoChunks,
} from "../../fs/util.js";

const storage = new EverCache("noneos-blocks-data");

userMiddleware.set("get-block", async (data, client) => {
  debugger;
});

// 将数据保存到本地，等待对方来获取块数据
export const saveBlock = async ({ data, filePath }) => {
  if (filePath) {
    debugger;
  }

  const chunks = await splitIntoChunks(data, CHUNK_REMOTE_SIZE);

  // 主要缓存的文件夹
  const blocksCacheDir = await get("local/caches/blocks", {
    create: "dir",
  });

  return Promise.all(
    chunks.map(async (chunk) => {
      const hash = await calculateHash(chunk);

      // 保存缓存文件的信息
      storage.setItem(hash, {
        time: Date.now(),
      });

      const fileHandle = await blocksCacheDir.get(hash, {
        create: "file",
      });

      await fileHandle.write(chunk);

      return hash;
    })
  );
};

// 根据块信息，获取本地块信息
export const getBlock = async ({ hash, filePath }) => {};
