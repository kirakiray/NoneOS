# mcu-ts

This algorithm was copied and modified from [material-color-utilities](https://github.com/material-foundation/material-color-utilities/tree/main/typescript)