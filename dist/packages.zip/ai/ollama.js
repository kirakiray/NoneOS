let ollamaHost = localStorage.getItem("ollamaHost") || "http://localhost:11434";

export const setOllamaHost = (host) => {
  if (ollamaHost !== host) {
    ollamaHost = host;
    localStorage.setItem("ollamaHost", host);
  }
};

export const getOllamaHost = () => {
  return ollamaHost;
};

export async function getOllamaModels() {
  const response = await fetch(ollamaHost + "/api/tags");
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  const data = await response.json();
  return data.models;
}

export const deleteOllamaModel = async (model) => {
  const result = await fetch(ollamaHost + "/api/delete", {
    method: "DELETE",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name: model }),
  }).then((e) => e.text());

  return result;
};

const processStreamResponse = async (response, callback) => {
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let result = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    const chunk = decoder.decode(value);
    const lines = chunk.split("\n").filter((line) => line.trim() !== "");

    for (const line of lines) {
      try {
        const parsed = JSON.parse(line);
        if (callback) {
          callback(parsed);
        }

        // 根据响应类型提取内容
        if (parsed.response) {
          result += parsed.response;
        } else if (parsed.status) {
          result += parsed.status;
        }
      } catch (e) {
        console.error("Error parsing JSON:", e);
      }
    }
  }

  return result;
};

export const pullOllamaModel = async (model, callback) => {
  try {
    const response = await fetch(ollamaHost + "/api/pull", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: model,
        stream: true,
      }),
    });

    let result = "";
    await processStreamResponse(response, (parsed) => {
      if (callback && parsed.status) {
        callback(parsed.status);
      }
      if (parsed.status) {
        result += parsed.status;
      }
    });

    return result;
  } catch (error) {
    console.error("Error pulling Ollama model:", error);
    return null;
  }
};

export async function askOllamaStream(
  prompt,
  model = "qwen3:4b-instruct",
  callback
) {
  try {
    const response = await fetch(ollamaHost + "/api/generate", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: model,
        prompt: prompt,
        stream: true,
        options: {
          num_ctx: 1024 * 32, // 上下文窗口大小
          temperature: 0.7, // 创造性程度
          repeat_penalty: 1.1,
          num_predict: 1024 * 128, // 最大生成长度
          enable_thinking: "False",
        },
      }),
    });

    let result = "";
    await processStreamResponse(response, (parsed) => {
      if (parsed.response) {
        result += parsed.response;
        if (callback) callback(parsed.response);
      }
    });

    return result;
  } catch (error) {
    const err = new Error("Error communicating with Ollama: " + error.message, {
      cause: error,
    });

    throw err;
  }
}
