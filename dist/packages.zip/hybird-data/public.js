export const reservedKeys = ["dataStatus", "_dataId", "_spaceHandle"];

export const Identification = "__dataid__";

import { HybirdData } from "./hybird-data.js";

// 保存数据
export const saveData = async (hydata) => {
  hydata.dataStatus = "saving";

  const finnalData = {};

  await Promise.all(
    Object.entries(hydata).map(async ([key, value]) => {
      if (reservedKeys.includes(key)) {
        return;
      }

      // 如果是对象，递归处理
      if (value !== null && typeof value === "object") {
        await saveData(value);
        finnalData[key] = `${Identification}${value._dataId}`;
        return;
      }

      finnalData[key] = value;
    })
  );

  let fileHandle;

  if (hydata.__newHy) {
    fileHandle = await hydata._spaceHandle.get(hydata._dataId, {
      create: "file",
    });
  } else {
    // 监听数据变化，实时写入到 handle 中
    fileHandle = await hydata._spaceHandle.get(hydata._dataId);
  }

  const oldText = await fileHandle.text();
  const newText = JSON.stringify(finnalData);
  if (oldText === newText) {
    // 数据没有变化，不需要写入
    hydata.dataStatus = "ok"; // 数据没有变化，不需要写入，直接返回，不触发 dataStatus 的变化
    return;
  }

  console.log("savedata", hydata); // eslint-disable-line no-cons

  // 数据变化，写入到 handle 中
  await fileHandle.write(newText, {
    remark: `writedby-${hydata._root.xid}`,
  });

  if (oldText) {
    // 根据旧的数据，删除掉没有使用的对象文件
    const oldData = JSON.parse(oldText);
    const oldValues = Object.values(oldData);
    const newValues = Object.values(finnalData);
    const deleteValues = oldValues.filter((val) => !newValues.includes(val)); // 已被删除的value
    if (deleteValues.length) {
      await Promise.all(deleteValues.map((e) => removeData(e, hydata)));
    }
  }

  hydata.dataStatus = "ok";
};

const removeData = async (oldData, exitedData) => {
  if (typeof oldData !== "string" || !oldData.startsWith(Identification)) {
    return;
  }

  const dataId = oldData.replace(Identification, "");

  const rootMapper = exitedData._root._rootMapper; // 获取根对象的rootMapper

  // 从根上获取该对象
  const targetData = rootMapper.get(dataId);
  // 删除数据及其关联对象的具体实现
  const deleteDataAndRelated = async () => {
    targetData[NEEDREMOVEDATA] = true;

    // 删除子对象
    const childDeletions = Object.entries(targetData)
      .filter(([_, val]) => typeof val === "object")
      .map(([_, val]) =>
        removeData(`${Identification}${val._dataId}`, exitedData)
      );

    await Promise.all(childDeletions);

    // 清理数据
    rootMapper.delete(dataId);

    const fileHandle = await targetData._spaceHandle.get(dataId);
    if (fileHandle) {
      await fileHandle.remove();
    }
  };

  // 检查是否可以删除数据
  let canDelete = true;

  if (targetData.owner.size) {
    // 如果存在一个未被删除的owner，那么不能删除数据
    if (
      Array.from(targetData.owner).some((e) => {
        return e instanceof HybirdData && !e[NEEDREMOVEDATA];
      })
    ) {
      canDelete = false;
    }
  }

  if (canDelete) {
    await deleteDataAndRelated();
  }
};

const NEEDREMOVEDATA = Symbol("needRemoveData");

export const getRandomId = () => Math.random().toString(36).slice(2);
