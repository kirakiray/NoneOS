import { setSpace } from "./data.js";
