import { Stanz } from "../../libs/stanz/main.js";

export const connections = new Stanz([]);
