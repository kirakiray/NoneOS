import { handoutCard } from "./handout-card.js";

export { handoutCard };
