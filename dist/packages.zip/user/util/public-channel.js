// local-user 共享的广播通道
export const publicBroadcastChannel = new BroadcastChannel(
  "local-user-broadcast-channel"
);
