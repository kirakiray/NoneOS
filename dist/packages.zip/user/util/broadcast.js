// local-user 共享的广播通道
export const broadcast = new BroadcastChannel("local-user-broadcast-channel");
