# db-handle

基于 indexdb 实现的文件系统。

但在safari下，indexdb会有很多莫名其妙的问题，遂准备弃用。

这里不删除，以后说不定有用。