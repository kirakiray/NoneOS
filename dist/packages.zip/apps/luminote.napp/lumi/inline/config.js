// import quote from "./lumi-quote/config.js";
import createArticle from "./lumi-create-article/config.js";
import link from "./lumi-link/config.js";

export const inlineComps = [link, createArticle];
