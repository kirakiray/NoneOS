import quote from "./lumi-quote/config.js";

export const inlineComps = [quote];
