import code from "./lumi-code/config.js";
import checkbox from "./lumi-checkbox/config.js";
import listItem from "./lumi-list-item/config.js";

export const blockComps = [code, checkbox, listItem];
