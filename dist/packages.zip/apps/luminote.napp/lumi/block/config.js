import code from "./lumi-code/config.js";

export const blockComps = [code];
