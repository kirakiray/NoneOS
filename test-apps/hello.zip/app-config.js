export const home = "./home.html";
